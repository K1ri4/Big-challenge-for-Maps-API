from library import os
from settings import *
from request import request


zoom = float(input('Введите масштаб карты: '))  # запрос масштаба
while zoom > 90:  # верхняя граница 90
    zoom = float(input('Введите масштаб карты: '))
request('map', zoom=zoom)

while True:  # основной цикл программы
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            os.remove(name_map)  # удаление файла после завершения работы
            pygame.quit()
            break
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_m:
                request('map', zoom=zoom)
            elif event.key == pygame.K_s:
                request('sat', zoom=zoom)
            elif event.key == pygame.K_h:
                request('skl', zoom=zoom)
    screen.blit(pygame.image.load(name_map), (0, 0))  # отображение карты
    pygame.display.flip()
    clock.tick(fps)
