import os
import sys

import pygame
import requests

pygame.init()
