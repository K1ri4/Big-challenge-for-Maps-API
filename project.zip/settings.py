from library import pygame


pygame.display.set_caption('Большая задача по Maps API.')
screen = pygame.display.set_mode((600, 450))

fps = 30
clock = pygame.time.Clock()
name_map = 'map.png'
